package mavenTest.OpusPR;

import lib.ExcelDataConfig;

public class ReadExcelData {

	public static void main(String[] args) {
		ExcelDataConfig excel = new ExcelDataConfig();
		//System.out.println(excel.getData(1, 1, 4));
		
		String dtv =excel.getData(1, 1, 4);
		System.out.println("Vaule of DTV is " +dtv);
		
		String 	secPasscode,secAns,primPhone,primPhoneType,contactPref,altPhone, altPhoneType,altContactPref  ;
		secPasscode= excel.getData(3, 1, 5);		
		secAns= excel.getData(3, 1, 6);		
		primPhone= excel.getData(3, 1, 7);	
		primPhoneType= excel.getData(3, 1, 8);	
		contactPref= excel.getData(3, 1, 9);	
		altPhone= excel.getData(3, 1, 10);	
		altPhoneType= excel.getData(3, 1, 11);
		altContactPref= excel.getData(3, 1, 12);
		
		System.out.println("Primary Phone no: "+primPhone);
		System.out.println("Primary Phone type: "+primPhoneType);
		System.out.println("contactPref: "+contactPref);
		System.out.println("ALT Phone no: "+altPhone);
		System.out.println(" ALTPrimary Phone type: "+altPhoneType);
		System.out.println("ALT contactPref: "+altContactPref);
		
		String dob ;
		dob= excel.getData(3, 1, 2);
		System.out.println("Inputted DOB is :"+dob);
		String d= dob.substring(0, 2);
		System.out.println("DOB :" +d);
		
		String day = dob.substring(3,5);
		
		System.out.println("month" +day);
		String[] arrOfStr = dob.split("/", 3); 
		  
        for (String a : arrOfStr) 
            System.out.println(a); 
		
		
		if(dtv.equals("Y"))
		{
			System.out.println("Vaule of DTV is : "+dtv +" "+excel.getData(1, 1, 4));
		}
		else
		{
			System.out.println("Value not found");
		}
	}

}
