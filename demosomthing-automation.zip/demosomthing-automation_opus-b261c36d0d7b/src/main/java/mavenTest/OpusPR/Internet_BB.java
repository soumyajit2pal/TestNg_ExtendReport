package mavenTest.OpusPR;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import lib.ExcelDataConfig;

public class Internet_BB {
	
	ExcelDataConfig excel = new ExcelDataConfig();
	
	public WebDriver internetPlan(WebDriver driver)
	{
		try {
			Thread.sleep(4000);
			
			//WebElement clickInternet = driver.findElement(By.xpath("//*[@id='internetOffer']"));
			//clickInternet.click();
			System.out.println("selecting hsia card");
					
			WebElement clickHSIAoffer = driver.findElement(By.xpath("//*[@id='productSelectedOfferForHsi']"));
			clickHSIAoffer.click();
			
		} 
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		
		return driver;
		
	}

}
