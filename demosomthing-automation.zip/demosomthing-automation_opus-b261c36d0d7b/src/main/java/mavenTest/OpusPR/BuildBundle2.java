package mavenTest.OpusPR;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import lib.Locators;
import lib.Screenshot;

public class BuildBundle2 {

	
	public WebDriver bundleSummary(WebDriver driver)
	{
		
		//WebDriverWait oWait = new WebDriverWait (driver, 30);
		//WebElement e = oWait.until(ExpectedConditions.visibilityOf(driver.findElement(Locators.contOrder)));
		
		try {
			/*Thread.sleep(6000);
			WebElement Closepopup= driver.findElement(Locators.Closepopup);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", Closepopup); */
			
		
	
			
			WebElement clickPopup = driver.findElement(By.xpath("//*[@id='closeOverlay']"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", clickPopup);
			System.out.println(">>>>>>>>popup closed<<<<<<<<<");
			
			
			
			
			clickPopup.click();
			//Thread.sleep(4000);
		
			Screenshot.captureScreenshot(driver, "validated offers---7");
			//Thread.sleep(4000);
			
			WebElement corder= driver.findElement(Locators.contOrder);
			//JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", corder);
			Thread.sleep(4000);
			System.out.println("------------------Waiting to Load Create Account Page --------------------------");
			/*
			js.executeScript("arguments[0].click();", corder);
			Thread.sleep(4000);
			System.out.println("------------------Waiting to Load Create Account Page --------------------------");
			*/
			Thread.sleep(2000000);
		} 
		catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return driver;
	}
}
