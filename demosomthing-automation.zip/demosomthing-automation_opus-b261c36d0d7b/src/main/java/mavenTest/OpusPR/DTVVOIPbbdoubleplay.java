package mavenTest.OpusPR;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import lib.Locators;
import lib.Screenshot;

public class DTVVOIPbbdoubleplay {

	public WebDriver selectOffersvoip(WebDriver driver)
		{
			try 
				{
				
				
				
				
				Thread.sleep(3000);	
		
				Screenshot.captureScreenshot(driver, "voip Card before selection");
				
		
				Thread.sleep(2000);
				
				WebElement clickdtvoffer = driver.findElement(By.xpath("//*[@id='productSelectedOfferForVoip']"));
				
				Screenshot.captureScreenshot(driver, "voip Card after selection2");
				
				Thread.sleep(2000);
				
				clickdtvoffer.click();
		
		
				System.out.println("dtv selected");
		
			
		System.out.println("voip offers selected");
		
		
		//click on Validate Order
				WebElement valiadteorder= driver.findElement(Locators.validateQuote);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", valiadteorder);
				
				Thread.sleep(2000);
				
				WebElement dtvvoippopup = driver.findElement(By.xpath("//*[@id='closeOverlay']"));
				js.executeScript("arguments[0].click();", dtvvoippopup);
				
				Thread.sleep(2000);
	
		
			
	}
	
	catch (Exception e) 
	{
		
		e.printStackTrace();
	}
		return driver;
		
		}
}
	
	
	
	