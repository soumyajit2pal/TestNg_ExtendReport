package mavenTest.OpusPR;



import org.junit.Test;
import org.openqa.selenium.WebDriver;

public class DTVStandalone {

	WebDriver driver = null;

	
	@Test
	public void OpusFlow() throws InterruptedException
	{
		OpusOperations launchOpus = new OpusOperations();
		//OpusOperations globalLogon = new OpusOperations();
		OPUSCreateCustOps CreateCust = new OPUSCreateCustOps();
		
		ServiceProfileForNewCustDTVStanalone service = new ServiceProfileForNewCustDTVStanalone();
		
		Dtvstandalonebb dtvbb= new Dtvstandalonebb();
		
		//BuildMyBundle bb_page = new BuildMyBundle();
		BuildBundle2 bb_page2 = new BuildBundle2();
		
		
		// CustCheckout_sign sign = new CustCheckout_sign();
		
		// ReceiptPreference rpref = new ReceiptPreference();
		
		
		//-------------------------------------
		driver = launchOpus.launchOpus(driver);
		//-------------------------------------
		
		Thread.sleep(5000);
		
		//------------------------------------
		driver = launchOpus.globalLogon(driver);
		//------------------------------------
		
		Thread.sleep(10000);
		
		driver = CreateCust.enterAddress(driver);
		
		//------------------------------------
		
		Thread.sleep(10000);
				
		driver = service.serviceAvailability(driver);
		
		//------------------------------------
		
		Thread.sleep(10000);
		
		driver = dtvbb.selectOffersdtv(driver);
		
		//------------------------------------
		
		//Thread.sleep(5000);
		//driver= bb_page.selectOffers(driver);
	
		//------------------------------------
	
		Thread.sleep(10000);
		driver= bb_page2.bundleSummary(driver);
		
		//-----------------------------------------
		Thread.sleep(8000);
	
		//-----------------------------------------
//		Thread.sleep(4000);	
//		driver = sign.custSign(driver);

		//-----------------------------------------
//		Thread.sleep(5000);
//		driver = rpref.receiptPref(driver);
		
		
		
	}

}
