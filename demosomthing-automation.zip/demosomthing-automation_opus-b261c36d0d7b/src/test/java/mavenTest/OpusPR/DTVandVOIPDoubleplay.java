/**
 * 
 */
package mavenTest.OpusPR;

import org.junit.Test;
import org.openqa.selenium.WebDriver;

/**
 * @author kiran Nikam
 *
 */
public class DTVandVOIPDoubleplay {

	/**
	 * DTV +HSIA + VOIP
	 */

	WebDriver driver = null;

	
	@Test
	public void OpusFlow() throws InterruptedException
	{
		OpusOperations launchOpus = new OpusOperations();
		//OpusOperations globalLogon = new OpusOperations();
		OPUSCreateCustOps CreateCust = new OPUSCreateCustOps();
		
		ServiceProfileForDTVandVoipDoubleplay service = new ServiceProfileForDTVandVoipDoubleplay();
		
		
		DTVvoipbb DTVvoipbb= new DTVvoipbb();
		
		//BuildMyBundle bb_page = new BuildMyBundle();
		DTVVOIPbbdoubleplay dtvvoip_bb = new DTVVOIPbbdoubleplay();
		BuildBundle2 bb_page2 = new BuildBundle2();
	
		
		// ReceiptPreference rpref = new ReceiptPreference();
		
		OrderConfirmation confirmorder = new OrderConfirmation();
		//-------------------------------------
		driver = launchOpus.launchOpus(driver);
		//-------------------------------------
		
		Thread.sleep(5000);
		
		//------------------------------------
		driver = launchOpus.globalLogon(driver);
		//------------------------------------
		
		Thread.sleep(10000);
		
		driver = CreateCust.enterAddress(driver);
		
		//------------------------------------
		
		Thread.sleep(10000);
				
		driver = service.serviceAvailability(driver);
		
		//------------------------------------
		
		Thread.sleep(10000);
		
		driver = DTVvoipbb.selectOffersdtv(driver);
		
		//------------------------------------
		
		Thread.sleep(5000);
		//driver= bb_page.selectOffers(driver);
		//------------------------------------
		
		Thread.sleep(5000);
		driver= dtvvoip_bb.selectOffersvoip(driver);
		
		
	
		//------------------------------------
	
		Thread.sleep(10000);
		driver= bb_page2.bundleSummary(driver);
		
		//-----------------------------------------
		Thread.sleep(8000);
	
		driver = confirmorder.Orderconfirm(driver);
		
		//-----------------------------------------
//		Thread.sleep(4000);	
//		driver = sign.custSign(driver);

		//-----------------------------------------
//		Thread.sleep(5000);
//		driver = rpref.receiptPref(driver);
		
		
		
	}

}
