package basicFactor;

public class SetExcelPath {

	public String return_excel_path() throws Exception{
		String Excel_name=System.getProperty("user.dir")+".\\TestData\\"+"OpusTestCase.xlsx";
		return Excel_name;
	}
}
