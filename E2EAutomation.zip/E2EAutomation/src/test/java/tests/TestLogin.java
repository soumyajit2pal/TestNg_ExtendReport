package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import utils.ConfigReader;

public class TestLogin extends BaseTest {

    @Test(description = "Verify user login functionality")
    public void testLogin(){
        test = extent.createTest("TCID-001: Login Test")
                .assignCategory("Authentication")
                .assignAuthor("QA Team")
                .info("Test Description: Verify user login functionality");
        driver.get(ConfigReader.getProperty("url"));
        driver.findElements(By.xpath("#124"));
    }
}
