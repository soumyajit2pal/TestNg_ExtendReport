package base;
import org.openqa.selenium.*;
import org.apache.commons.io.*;
import org.testng.annotations.*;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.testng.ITestContext;
import org.testng.ITestResult;

import utils.ConfigReader;
import utils.ExtentReportManager;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;

public class BaseTest {
    protected WebDriver driver;
    protected ExtentReports extent;
    protected ExtentTest test;

    @BeforeTest
    public void setup(ITestContext context) {
        extent = ExtentReportManager.getInstance();
    }
    @BeforeMethod
    public void setUp() {
        ConfigReader.loadProperties();
        driver = DriverFactory.getDriver();
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void gererateReport(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            test.fail("Test Failed: " + result.getThrowable());
            captureScreenshot(result.getMethod().getMethodName());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            test.pass("Test Passed");
        }
        extent.flush();
    }

    @AfterTest
    public void closeReport() {
        extent.flush();
    }

    @AfterMethod
    public void tearDown() {
        DriverFactory.quitDriver();
    }

    // 📸 Capture Screenshot on Failure
    public void captureScreenshot(String testName) {
        try {
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String screenshotPath = "test-output/screenshots/" + testName + "_" + timestamp +".png";
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destFile = new File(screenshotPath);

            try {
                FileUtils.copyFile(srcFile, destFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
            test.fail("Screenshot on failure",
                    com.aventstack.extentreports.MediaEntityBuilder.createScreenCaptureFromPath("..//"+screenshotPath).build());
        } catch (Exception e) {
            test.warning("Failed to capture screenshot: " + e.getMessage());
        }
    }
}
