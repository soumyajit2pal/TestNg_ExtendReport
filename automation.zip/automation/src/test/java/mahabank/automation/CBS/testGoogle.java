package mahabank.automation.CBS;

import mahabank.automation.base.ProjectHookes;
import mahabank.automation.config.ConfigurationManager;
import org.testng.annotations.Test;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class testGoogle extends ProjectHookes {

    @Test(description = "New CIF Creation Validation")
    public void testCreationOnCIF(){
        String testcaseName = "TC01 - Customer Create Account";
        String testDescription = "Create New Account with mandatory fields";
        String authors = "QA Team";
        String category = "Sanity";
        startTestCase(testcaseName, testDescription, authors, category);
        navigate(ConfigurationManager.configuration().baseUrl());
        type("[title=\"Search\"]", "abc", "Search");
        verifyDisplayed("ab", "test");
    }

    @Test(description = "2 New CIF Creation Validation")
    public void testCreationOnCIF2(){
        String testcaseName = "TC012 - Customer Create Account";
        String testDescription = "Create New Account with mandatory fields";
        String authors = "QA Team";
        String category = "Regression";
        startTestCase(testcaseName, testDescription, authors, category);
        navigate(ConfigurationManager.configuration().baseUrl());
        type("[title=\"Search\"]", "abc", "Search");
//        verifyDisplayed("ab", "test");
//        assertThat(getPage().locator("ab")).isVisible();
    }
}
