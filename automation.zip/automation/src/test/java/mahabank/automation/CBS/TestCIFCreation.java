package mahabank.automation.CBS;

import mahabank.automation.base.ProjectHookes;
import mahabank.automation.config.ConfigurationManager;
import mahabank.automation.data.dynamic.FakeDataFactory;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.CustomerCreation;
import mahabank.automation.utility.ExcelUtil;
import org.testng.annotations.Test;

public class TestCIFCreation extends ProjectHookes {
    String testdataPath = "src/main/java/mahabank/automation/data/dynamic/cif_creation.xlsx";

    @Test(description = "New CIF Creation Validation")
    public void testCreationOnCIF(){
        String testcaseName = "TC01 - Customer Create Account";
        String testDescription = "Create New Account with mandatory fields";
        String authors = "QA Team";
        String category = "Sanity";
        startTestCase(testcaseName, testDescription, authors, category);
        navigate(ConfigurationManager.configuration().baseUrl());
        new CBSLoginPage().doLogin();

        new CBSHomePage().validateCBSHomeLoaded();
        new CBSHomePage().ClickOnCard("Customer Management");
        new CBSHomePage().ClickOnCard("Create");
        verifyDisplayed(getByText("Create Personal Customer Wizard"), "Create personal Customer Wizard");

        ExcelUtil personaldetails = new ExcelUtil(testdataPath,"Personal Details" );
        CustomerCreation cc = new CustomerCreation();

// Personal Details
        String firstname = personaldetails.getValueByColumnName(2, "First Name");
        String fathername = personaldetails.getValueByColumnName(2, "Father Name");
        String relativecode = personaldetails.getValueByColumnName(2, "Relative Code");
        String customerType =  personaldetails.getValueByColumnName(2, "Customer Type");
        String customerprefix =  personaldetails.getValueByColumnName(2, "Title");
        String pAddress1 =  personaldetails.getValueByColumnName(2, "Permanent Address 1");
        String pAddress2 =  personaldetails.getValueByColumnName(2, "Permanent Address 2");
        String pAddress3 =  personaldetails.getValueByColumnName(2, "Permanent Address 3");
        String pCityName = 	personaldetails.getValueByColumnName(2, "Permanent City Name");
        String pCityCode = 	personaldetails.getValueByColumnName(2, "Permanent City Code");
        String pPinCode = 	personaldetails.getValueByColumnName(2, "Permanent Pin Code");
        String pMobileNuber = 	personaldetails.getValueByColumnName(2, "Mobile Number");

        String DOB = personaldetails.getValueByColumnName(2, "Date Of Birth");
        String placeOfBirth = personaldetails.getValueByColumnName(2, "Place/City of birth");
        String gender = personaldetails.getValueByColumnName(2, "Gender Code");
        String maritalStatus = personaldetails.getValueByColumnName(2, "Marital Status");
        String language = personaldetails.getValueByColumnName(2, "Language");

        cc.enterFirstName(firstname);
        cc.enterFatherName(fathername);
        cc.setRelativeCode(relativecode);
        cc.selectCustomerType(customerType);
        cc.selectTitlePrefix(customerprefix);

        cc.setPermanentAddress1(pAddress1);
        cc.setPermanentAddress2(pAddress2);
        cc.setPermanentAddress3(pAddress3);
        cc.setCityNamePermananentAddress(pCityName);
        cc.setCityCodePermananentAddress(pCityCode);
        cc.setPinCodePermananentAddress(pPinCode);
        cc.checkIsCurrentSameAsPermanent(true);
        cc.clickFetchButtonPermanentAddress();

        cc.setMobileNumber(pMobileNuber);
        cc.validateMobileNumber();
        cc.setOTP();
        cc.validateOTPonMobileNumber();

        cc.selectDOB(DOB);
        cc.setPlaceCityOfBirth(placeOfBirth);
        cc.selectGender(gender);
        cc.selectLanguage(language);
        cc.selectMaritalStatus(maritalStatus);

        cc.completeUserConsent();
        cc.submitTransmit();

//        Identification Details
        String primaryId = personaldetails.getValueByColumnName(2, "Primary ID");
        String primaryIDNumber = personaldetails.getValueByColumnName(2, "Primary ID Number");
        String currentAddProof = personaldetails.getValueByColumnName(2, "Current Add Proof");
        String current_add_proof_no = personaldetails.getValueByColumnName(2, "Current Add Proof No");

        cc.selectPrimaryId(primaryId);
        cc.setPrimaryIdNumber(primaryIDNumber);
        cc.selectCurrentAddressProof(currentAddProof);
        cc.setCurrentAddressProofNumber(current_add_proof_no);
//        cc.setOvddocumentUpload("src/main/java/mahabank/automation/data/upload/test.jpeg");
//        cc.clickOvddocumentUploadButton();
        cc.completeUserConsent();
        cc.submitTransmit();

//      Non-Personal Details
        String segmentCode = personaldetails.getValueByColumnName(2, "Segmnet Code");
        String bsr4OrgCode = personaldetails.getValueByColumnName(2, "BSR-4 Org Code");
        String constitutionCode = personaldetails.getValueByColumnName(2, "Constitution code");
        String panOrForm = personaldetails.getValueByColumnName(2, "PAN OR Form 60/61");
        String minorityFlag = personaldetails.getValueByColumnName(2, "Minority Flag");
        String religionCaste = personaldetails.getValueByColumnName(2, "Religion/Caste Code");

        cc.selectSegmentCode(segmentCode);
        cc.selectBSR4OrgCode(bsr4OrgCode);
        cc.selectConstitutionCode(constitutionCode);
        cc.selectPanOrForm60(panOrForm);
        cc.selectMinorityFlag(minorityFlag);
        cc.selectReligionCasteCode(religionCaste);
        cc.completeUserConsentWhileNoPAN();
        cc.submitTransmit();

//   Internet Banking Details
        String requestForIb = personaldetails.getValueByColumnName(2, "Request for IB");
        String emailAddress = personaldetails.getValueByColumnName(2, "Email Address");
        String reason = personaldetails.getValueByColumnName(2, "Reason");

        cc.selectRequestForIB(requestForIb);
        cc.setEmailAddress(emailAddress);
        cc.selectReasonOnIB(reason);
        cc.completeUserConsentWhileNoPAN();
        cc.submitTransmit();

//   Occupation Details
        String occupationDescriptions = personaldetails.getValueByColumnName(2, "Occupation Description");
        String exServiceMan = personaldetails.getValueByColumnName(2, "Whether Ex-Serviceman");
        String manualScavenger = personaldetails.getValueByColumnName(2, "Whether Manual Scavenger");
        String occupationCode = personaldetails.getValueByColumnName(2, "Occupation Code");
        String annualIncome = personaldetails.getValueByColumnName(2, "Annual Income");
        String politicallyExposedPerson = personaldetails.getValueByColumnName(2, "Politically Exposed Person");
        String whetherPersonsWithDisabilities = personaldetails.getValueByColumnName(2, "Whether Persons with Disabilities");

        cc.selectOccupationDescrptions(occupationDescriptions);
        cc.selectEx_Serviceman(exServiceMan);
        cc.selectManualScavenge(manualScavenger);
        cc.selectPoliticallyExpose(politicallyExposedPerson);
        cc.selecttPersonDisablity(whetherPersonsWithDisabilities);

        cc.selectOccupationCode(occupationCode);
        cc.setAnnualIncome(annualIncome);

        cc.completeUserConsentWhileNoPAN();
        cc.submitTransmit();

        cc.retrieveQueueAfterCreation();
        getPage().pause();
    }


}
