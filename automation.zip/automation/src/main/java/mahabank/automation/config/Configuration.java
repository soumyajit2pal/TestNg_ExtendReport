package mahabank.automation.config;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.LoadPolicy;
import org.aeonbits.owner.Config.LoadType;
/*
 Owner @Soumyajit Pal
 */

@LoadPolicy(LoadType.MERGE)
@Config.Sources({
        "classpath:base.properties",
        "classpath:app.properties",
        "classpath:report.properties"})
public interface Configuration extends Config {

    @Key("browser")
    String browser();

    @Key("headless")
    Boolean headless();

    @Key("url.base")
    String baseUrl();

    @Key("timeout")
    int timeout();

    @Key("faker.locale")
    String faker();

    @Key("auto.login")
    boolean autoLogin();

    @Key("enable.tracing")
    boolean enableTracing();

    @Key("action.delay")
    double slowMotion();

    @Key("pause.low")
    long pauseLow();

    @Key("pause.medium")
    long pauseMedium();

    @Key("pause.high")
    long pauseHigh();

    @Key("max.retry")
    int maxRetry();

    @Key("app.username")
    String appUserName();

    @Key("app.password")
    String appPassword();

    @Key("app.branchname")
    String appBranchName();

    @Key("report.title")
    String reportTitle();

    @Key("report.name")
    String reportName();

    @Key("report.theme")
    String reportTheme();
}
