package mahabank.automation.utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import mahabank.automation.base.BrowserFactory;
import mahabank.automation.config.ConfigurationManager;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.aventstack.extentreports.model.Media;

public abstract class HtmlReporter extends BrowserFactory {

    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> parentTest = new ThreadLocal<>();
    private static final ThreadLocal<ExtentTest> test = new ThreadLocal<>();
    private static final ThreadLocal<String> testName = new ThreadLocal<>();

    private static final String pattern = "dd-MMM-yyyy HH-mm-ss";
    private static String folderName = "";
    private static final String REPORTS_DIR = "reports";

    public static String createFolder(String baseFolder) {
        String date = new SimpleDateFormat(pattern).format(new Date());
        String folderName = baseFolder + File.separator + date;
        File folder = new File(folderName);

        if (!folder.exists()) {
            if (folder.mkdirs()) {
                System.out.println("Folder created: " + folderName);
            } else {
                System.err.println("Failed to create folder: " + folderName);
            }
        }

        return folderName;
    }

    public synchronized void startReport() {
        folderName = createFolder(REPORTS_DIR);
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(folderName + "/ExtentReport.html");
        sparkReporter.config().setTheme(ConfigurationManager.configuration().reportTheme().equalsIgnoreCase("dark") ? Theme.DARK : Theme.STANDARD);
        sparkReporter.config().setDocumentTitle(ConfigurationManager.configuration().reportTitle());
        sparkReporter.config().setReportName(ConfigurationManager.configuration().reportName());

        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);
    }

    public synchronized void startTestCase(String testcaseName, String testDescription, String category, String authors) {
        ExtentTest parent = extent.createTest(testcaseName, testDescription).assignCategory(category).assignAuthor(authors);
        parentTest.set(parent);
        test.set(parent.createNode("Test Steps"));
        testName.set(testcaseName);

    }

    public synchronized ExtentTest getTest(){
        return test.get();
    }

    public synchronized ExtentTest getParentTest(){
        return parentTest.get();
    }

    public abstract String takeSnap();

    public void reportStep(String desc, String status, boolean bSnap) {
        synchronized (test) {
            Media img = null;
            if (bSnap && !(status.equalsIgnoreCase("INFO") || status.equalsIgnoreCase("skipped") )) {
                img = MediaEntityBuilder.createScreenCaptureFromBase64String(takeSnap()).build();
            }

            if (status.equalsIgnoreCase("pass")) {
//                test.get().pass(desc, img);
                test.get().pass(desc);
            } else if (status.equalsIgnoreCase("fail")) { // additional steps to manage alert pop-up
                test.get().fail(desc, img);
                throw new RuntimeException("See the reporter for details.");
            } else if (status.equalsIgnoreCase("warning")) {
                test.get().warning(desc, img);
            } else if (status.equalsIgnoreCase("skipped")) {
                test.get().skip("The test is skipped due to dependency failure");
            } else if (status.equalsIgnoreCase("INFO")) {
                test.get().info(desc);
            }
        }
    }

    public void reportStep(String desc, String status) {
        reportStep(desc, status, true);
    }

    public synchronized void endResult() {
        if (extent != null) {
            extent.flush();
        }
    }

    public String getTestName() {
        return testName.get();
    }
}
