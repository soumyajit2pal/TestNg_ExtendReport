package mahabank.automation.utility;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ExcelUtil {

    static String path;
    static String sheetname;

    public ExcelUtil(String path, String sheetname) {
        this.path= path;
        this.sheetname = sheetname;
    }

    public static String getValueByColumnName(int rowIndex, String columnName) {
        try (FileInputStream fis = new FileInputStream(new File(path));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetname);
            if (sheet == null) {
                throw new IllegalArgumentException("Sheet not found: " + sheetname);
            }

            // Get the first row (Header row)
            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new IllegalArgumentException("Header row is empty!");
            }

            // Create a mapping of column names to column indices
            Map<String, Integer> columnIndexMap = new HashMap<>();
            for (Cell cell : headerRow) {
                columnIndexMap.put(cell.getStringCellValue().trim(), cell.getColumnIndex());
            }

            // Check if the column exists
            if (!columnIndexMap.containsKey(columnName)) {
                throw new IllegalArgumentException("Column not found: " + columnName);
            }

            int colIndex = columnIndexMap.get(columnName);
            Row dataRow = sheet.getRow(rowIndex);
            if (dataRow == null) {
                throw new IllegalArgumentException("Row not found: " + rowIndex);
            }

            Cell cell = dataRow.getCell(colIndex);
            return getCellValueAsString(cell);

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Convert cell value to String
    private static String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            default:
                return "";
        }
    }
}
