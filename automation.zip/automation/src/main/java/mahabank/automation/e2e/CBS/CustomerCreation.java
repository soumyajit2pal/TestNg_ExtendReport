package mahabank.automation.e2e.CBS;

public class CustomerCreation extends CBSHomePage{

    // Personal Deatils
    String firstname = "css=#UIPage_Wiz062001Personal_defaultString1";
    String fathername = "css=#UIPage_Wiz062001Personal_defaultString17";
    String customerType = "css=#UIPage_Wiz062001Personal_defaultString26";
    String titlePrefix = "css=#UIPage_Wiz062001Personal_title1";
    String permanentAddress1 = "css=#UIPage_Wiz062001Personal_permAddress1";
    String permanentAddress2 = "css=#UIPage_Wiz062001Personal_permAddress2";
    String permanentAddress3 = "css=#UIPage_Wiz062001Personal_permAddress3";
    String cityNamePermanentAddress = "css=#UIPage_Wiz062001Personal_permCityname";
    String cityCodePermananentAddress = "css=#UIPage_Wiz062001Personal_permCitycode";
    String pinCodePermananentAddress = "css=#UIPage_Wiz062001Personal_permPincode";
    String isCurrentSameAsPermanent= "css=#UIPage_Wiz062001Personal_checkboxes_personaltab";
    String mobileNumber = "css=#UIPage_Wiz062001Personal_defaultString12";
    String fetchButtonPermanentAddress = "css=#div-UIPage_060044_fetch_permDistPinCode";
    String dOBCalender = "css=#span-UIPage_Wiz062001Personal_date2";
    String yearDOBCalender ="css=.ui-datepicker-year";
    String monthDOBCalender = "css=.ui-datepicker-month";
    String dateDOBCalender(int month, String day){
        return "xpath=//td[@data-handler=\"selectDay\" and @data-month=\""+month+"\"]//a[text()=\""+day+"\"]";
    }
    String placeCityOfBirth = "css=[name=\"placeCityBirth\"]";
    String language = "css=[name=\"languagecode1\"]";
    String gender = "css=#UIPage_Wiz062001Personal_defaultString23";
    String maritalStatus = "css=#UIPage_Wiz062001Personal_defaultString24";
    String userConsent = "css=#UIPage_Wiz_062001Personal_UserConsentbtn";
    String aggreeUserConsent = "css=#UIPage_UserConsent_chceckbox";
    String submitUserConsent = "css=#UIPage_UserConsent_submit";
    String transmit = "xpath=//button[contains(text(), \"Transmit\")]";
    String relativeCode = "css=#UIPage_Wiz062001Personal_defaultString19";
    String validateMobileNumber = "css=#UIPage_Wiz062001Personal_validateNumber";
    String provideOTP = "css=#UIPage_Wiz062001Personal_otpNumber";
    String validatePersonalOTP = "css=#UIPage_Wiz062001Personal_validateOTP";

    //  Identification Details

    String primaryId = "#UIPage_Wiz062001Personal_id_type1";
    String primaryIdNumber = "#UIPage_Wiz062001Personal_defaultString13";
    String currentAddressProof = "#UIPage_Wiz062001Personal_id_type2";
    String currentAddressProofNumber = "#UIPage_Wiz062001Personal_defaultString40";
    String ovddocumentUpload = "input#UIPage_Wiz062001Personal_ovdDocument";
    String ovddocumentUploadButton = "css=#UIPage_Wiz062001Personal_ovdDocumentUpload";

//    Non Personal Details

    String segmentCode = "#UIPage_Wiz062001Personal_segm_code1";
    String bsr4OrgCode = "#UIPage_Wiz062001Personal_defaultString21";
    String constitutaionCode = "#UIPage_Wiz062001Personal_defaultString22";
    String panOrForm = "#UIPage_Wiz062001Personal_pANDD";
    String minorityFlag = "#UIPage_Wiz062001Personal_minorityflag";
    String religionOrCaste = "#UIPage_Wiz062001Personal_socialAttr_2";
    String form61Consent = "#UIPage_UserConsent_cb_form60_61";

//    Internet Banking Details
    String requestForIB = "#UIPage_Wiz062001Personal_defaultString41";
    String emailAddress = "#UIPage_Wiz062001Personal_defaultString43";
    String reasonForIB = "#UIPage_Wiz062001Personal_defaultString44";

//    Occupation Details
    String occupationDescrptions = "#UIPage_Wiz062001Personal_occ_Desc";
    String occupationCode = "#UIPage_Wiz062001Personal_occpn_code";
    String ex_Serviceman= "#UIPage_Wiz062001Personal_exServiceman";
    String manualScavenge = "#UIPage_Wiz062001Personal_mScavenger";
    String politicallyExpose = "#UIPage_Wiz062001Personal_politExpoPerson";
    String personDisablity = "#UIPage_Wiz062001Personal_pwd";
    String annualIncome = "#UIPage_Wiz062001Personal_annum2";

//    Customer Creation Alert
    String alert = "ul li[role=\"alert\"]";

    public void enterFirstName(String firstname){
        type(this.firstname,firstname, "Cutomer Firstname");
    }

    public void enterFatherName(String fathername){
        type(this.fathername,fathername, "Customer Father name");
    }

    public void setRelativeCode(String relativeCode){
        selectByText(this.relativeCode, relativeCode, "Relative Code");
    }

    public void selectCustomerType(String customertype){
        selectByText(customerType, customertype, "Customer Type");
    }


    public void selectTitlePrefix(String titleprefix){
        selectByText(this.titlePrefix, titleprefix, "Title Prefix");
    }

    public void setPermanentAddress1(String permanentAddress1){
        type(this.permanentAddress1, permanentAddress1, "Permanent Address 1");
    }

    public void setPermanentAddress2(String permanentAddress2){
        type(this.permanentAddress2, permanentAddress2, "Permanent Address 2");
    }

    public void setPermanentAddress3(String permanentAddress3){
        type(this.permanentAddress3, permanentAddress3, "Permanent Address 3");
    }

    public void setCityCodePermananentAddress(String cityCodePermananentAddress){
        type(this.cityCodePermananentAddress, cityCodePermananentAddress, "City Code Permanent Address");
    }

    public void setCityNamePermananentAddress(String cityNamePermanentAddress){
        type(this.cityNamePermanentAddress, cityNamePermanentAddress, "City Name Permanent Address");
    }

    public void setPinCodePermananentAddress(String pinCodePermananentAddress){
        type(this.pinCodePermananentAddress, pinCodePermananentAddress, "Pin Code Permanent Address");
    }

    public void checkIsCurrentSameAsPermanent(boolean check){
        if(check) {
            check(this.isCurrentSameAsPermanent, "Is Current Same As Permanent Address");
        }
    }

    public void clickFetchButtonPermanentAddress(){
        click(fetchButtonPermanentAddress, "Fetch button permananet address");
    }

    public void setMobileNumber(String mobileNumber){
        type(this.mobileNumber, mobileNumber, "Mobile Number");
    }

    public void validateMobileNumber(){
        click(validateMobileNumber, "Validate Mobile Number");
        click(OK, "OK");
    }

    public void setOTP(){
        type(provideOTP, "123456", "OTP");
    }

    public void validateOTPonMobileNumber(){
        click(validatePersonalOTP, "Validate OTP");
        click(OK, "OK");
    }

    public void openCalender(){
        click(dOBCalender, "Calender");
    }

    public void selectDOB(String date){
        String [] arr = date.split("/");
        int month = Integer.parseInt(arr[1])-1;
        openCalender();
        selectByText(yearDOBCalender, arr[2], "Year of Birth");
        selectByIndex(monthDOBCalender, month, "Month of Birth");
        click(dateDOBCalender(month, arr[0]), "Date Of Birth");
    }

    public void setPlaceCityOfBirth(String placeCityOfBirth){
        type(this.placeCityOfBirth, placeCityOfBirth, "Place Of Birth");
    }

    public void selectGender(String gender){
        selectByText(this.gender, gender, "Gender");
    }

    public void selectMaritalStatus(String maritalStatus){
        selectByText(this.maritalStatus, maritalStatus, "MaritalStatus");
    }

    public void selectLanguage(String language){
        selectByText(this.language, language, "Language");
    }

    public void getUserConsent() {
        click(userConsent, "User Consent");
    }

    public void checkAggreeUserConsent(){
        check(aggreeUserConsent, "Aggree User Consent");
    }

    public void submitUserConsent(){
        click(submitUserConsent, "Submit User Consent");
    }

//    Identification Details

    public void  selectPrimaryId(String primaryId){
        selectByText(this.primaryId, primaryId, "Primary ID");
    }
    public void setPrimaryIdNumber(String primaryIdNumber){
        type(this.primaryIdNumber, primaryIdNumber, "Primary ID Number");
    }
    public void selectCurrentAddressProof(String currentAddressProof){
        selectByText(this.currentAddressProof, currentAddressProof, "Current Add Proof");
    }
    public  void setCurrentAddressProofNumber(String currentAddressProofNumber){
        type(this.currentAddressProofNumber, currentAddressProofNumber, "Current Add Proof No");
    }
    public void setOvddocumentUpload(String path){
        uploadFile(ovddocumentUpload, path, "OVD File Upload");
    }
    public void clickOvddocumentUploadButton(){
        click(ovddocumentUploadButton, "OVD Upload Button");
    }

// Non-Personal Details

    public  void selectSegmentCode(String segmentCode){
        selectByText(this.segmentCode, segmentCode, "Segment Code");
    }

    public void selectBSR4OrgCode(String bsr4OrgCode){
        selectByText(this.bsr4OrgCode, bsr4OrgCode, "BSR-4 Org Code");
    }

    public void selectConstitutionCode(String constitutaionCode){
        selectByText(this.constitutaionCode, constitutaionCode, "Constitution code");
    }

    public void selectMinorityFlag(String minorityFlag){
        selectByText(this.minorityFlag, minorityFlag, "Minority Flag");
    }

    public void selectPanOrForm60(String panOrForm){
        selectByText(this.panOrForm, panOrForm, "PAN OR Form 60/61");
    }

    public void selectReligionCasteCode(String religionOrCaste){
        selectByText(this.religionOrCaste, religionOrCaste, "Religion/Caste Code");
    }

    public void checkForm61Consent(){
        check(form61Consent, "Checkbox form61/61 form, from the customer.");
    }

//    Internet Banking Details

    public void selectRequestForIB(String requestForIB){
        selectByText(this.requestForIB, requestForIB, "Request for IB");
    }

    public void setEmailAddress(String emailAddress){
        type(this.emailAddress, emailAddress, "Email Address");
    }

    public void selectReasonOnIB(String reasonForIB){
        selectByText(this.reasonForIB, reasonForIB, "Reason");
    }

    //    Occupation Details

    public void selectOccupationDescrptions(String occupationDescrptions){
        selectByText(this.occupationDescrptions, occupationDescrptions, "Occupation Description");
    }

    public void selectOccupationCode(String occupationCode){
        selectByText(this.occupationCode, occupationCode, "Occupation Code");
    }

    public void setAnnualIncome(String annualIncome){
        type(this.annualIncome, annualIncome, "Annual Income");
    }

    public void selectEx_Serviceman(String exServiceman){
        selectByText(this.ex_Serviceman, exServiceman, "Whether Ex-Serviceman");
    }

    public void selectManualScavenge(String manualScavenge){
        selectByText(this.manualScavenge, manualScavenge, "Whether Manual Scavengern");
    }

    public void selectPoliticallyExpose(String politicallyExpose){
        selectByText(this.politicallyExpose, politicallyExpose, "Politically Exposed Person");
    }

    public void selecttPersonDisablity(String personDisablity){
        selectByText(this.personDisablity, personDisablity, "Whether Persons with Disabilities");
    }

// Common Operations
    public void submitTransmit(){
        click(transmit, "Submit Transmit");
    }

    public void completeUserConsent(){
        getUserConsent();
        checkAggreeUserConsent();
        submitUserConsent();
    }

    public void completeUserConsentWhileNoPAN(){
        getUserConsent();
        checkAggreeUserConsent();
        checkForm61Consent();
        submitUserConsent();
    }

    public void retrieveQueueAfterCreation(){
        reportStep(getInnerText(alert), "warning");
    }
}
