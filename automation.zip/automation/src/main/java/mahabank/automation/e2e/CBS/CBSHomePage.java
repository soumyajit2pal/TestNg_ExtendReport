package mahabank.automation.e2e.CBS;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class CBSHomePage  extends CBSLoginPage{

    String homeButton = "css=.homeDiv";
    String logoutButton = "css=.logOutDiv";

    public CBSHomePage validateCBSHomeLoaded(){
        verifyDisplayed(homeButton, "Home button");
        return this;
    }

    public CBSHomePage ClickOnCard(String cardName){
        getPage().getByText(cardName).click();
        return this;
    }
}
