package mahabank.automation.e2e.CBS;

import mahabank.automation.base.ProjectHookes;

public class BasePage extends ProjectHookes {
    String OK = "css=#ok-button";
}
