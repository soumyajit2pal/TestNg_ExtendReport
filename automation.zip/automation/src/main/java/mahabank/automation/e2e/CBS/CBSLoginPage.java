package mahabank.automation.e2e.CBS;

import com.microsoft.playwright.BrowserContext;
import mahabank.automation.base.ProjectHookes;
import mahabank.automation.config.ConfigurationManager;

import java.nio.file.Paths;

public class CBSLoginPage extends BasePage {


    String username = "css=#login-username";
    String password = "css=#password";
    String branchname = "css=#login-branch";
    String loginButton = "css=#bmaLogin";

    public CBSLoginPage typeUserName(String username){
        type(this.username, username, "Username");
        return this;
    }

    public  CBSLoginPage typePassword(String password){
        type(this.password, password, "Password");
        return this;
    }

    public CBSLoginPage typeBranchName(String BranchName){
        type(this.branchname, BranchName, "Branch Name");
        return this;
    }

    public CBSLoginPage clickLogin(){
            click(loginButton, "Login");
            return this;
    }

    public CBSLoginPage doLogin(){
        if(isVisible(loginButton)) {
            typeUserName(ConfigurationManager.configuration().appUserName())
                    .typePassword(ConfigurationManager.configuration().appPassword())
                    .typeBranchName( ConfigurationManager.configuration().appBranchName())
                    .clickLogin();
            getContext().storageState(new BrowserContext.StorageStateOptions().setPath(Paths.get("storage/login.json")));
            reportStep("Login Successfully", "Pass");
        }
        return this;
    }
}
