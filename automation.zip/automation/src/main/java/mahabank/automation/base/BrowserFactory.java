package mahabank.automation.base;

import com.microsoft.playwright.*;
import mahabank.automation.config.ConfigurationManager;

/*
 @Owner Soumyajit Pal
 */
public class BrowserFactory {
    private static final ThreadLocal<Playwright> playwright = new ThreadLocal<Playwright>();
    private static final ThreadLocal<Browser> driver = new ThreadLocal<Browser>();
    protected static final ThreadLocal<BrowserContext> context = new ThreadLocal<BrowserContext>();
    protected static final ThreadLocal<Browser.NewContextOptions> contextOptions = new ThreadLocal<Browser.NewContextOptions>();
    protected static final ThreadLocal<Page> page = new ThreadLocal<Page>();
    protected static final ThreadLocal<Page> secondPage = new ThreadLocal<Page>();
    protected static final ThreadLocal<FrameLocator> frameLocator = new ThreadLocal<FrameLocator>();

    /**
     * Launches the preferred browser in the head(less) mode.
     * @param browser The accepted browsers are chrome, edge, firefox, safari (webkit)
     * @param headless Send true if you like to run in headless mode else false
     * @author Soumyajit Pal
     */

    public void setDriver(String browser, boolean headless) {
//        System.setProperty("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "0");
        playwright.set(Playwright.create());
        switch (browser) {
            case "chrome":
                driver.set(getPlaywright().chromium().launch(
                        new BrowserType.LaunchOptions().setChannel("chrome")
                                .setHeadless(false)));
//                                .setSlowMo(ConfigurationManager.configuration().slowMotion())));
                break;
            case "edge":
                driver.set(getPlaywright().chromium().launch(
                        new BrowserType.LaunchOptions().setChannel("msedge")
                                .setHeadless(headless)
                                .setSlowMo(ConfigurationManager.configuration().slowMotion())));
                break;
            case "firefox":
                driver.set(getPlaywright().firefox().launch(
                        new BrowserType.LaunchOptions()
                                .setHeadless(headless)
                                .setSlowMo(ConfigurationManager.configuration().slowMotion())));
            case "safari":
                driver.set(getPlaywright().webkit().launch(
                        new BrowserType.LaunchOptions()
                                .setHeadless(headless)
                                .setSlowMo(ConfigurationManager.configuration().slowMotion())));
            default:
                System.out.println("No driver");
                break;
        }
    }

    public Browser getDriver() {
        return driver.get();
    }

    public BrowserContext getContext() {
        return context.get();
    }

    public Browser.NewContextOptions getContextOptions(){
        return contextOptions.get();
    }

    public Page getPage() {
        return page.get();
    }

    public Page getSecondPage() {
        return secondPage.get();
    }

    public FrameLocator getFrameLocator() {
        return frameLocator.get();
    }

    public Playwright getPlaywright() {
        return playwright.get();
    }
}
