package mahabank.automation.base;

import com.aventstack.extentreports.Status;
import com.microsoft.playwright.Browser;
import mahabank.automation.config.ConfigurationManager;
import org.testng.ITestResult;
import org.testng.annotations.*;
import java.nio.file.Paths;
import java.util.Base64;

public class ProjectHookes extends PlaywrightWrapper {

    /**
     * Initializes reporting before the test suite execution.
     */
    @BeforeSuite
    public void initSuite() {
        startReport();
    }

    /**
     * Takes a screenshot in Base64 format.
     *
     * @return Base64 encoded screenshot
     */
    @Override
    public String takeSnap() {
        return Base64.getEncoder().encodeToString(getPage().screenshot());
    }

    /**
     * Initializes the browser, reporting, context, and page before each test method.
     */
    @BeforeMethod
    public void init() {
        try {
            initializeBrowser();
            setupContextAndPage();
        } catch (Exception e) {
            logError("Browser initialization failed: " + e.getMessage(), e);
        }
    }

    /**
     * Configures and launches the browser based on configuration.
     */
    private void initializeBrowser() {
        setDriver(ConfigurationManager.configuration().browser(), ConfigurationManager.configuration().headless());
    }

    /**
     * Sets up the browser context, page, and applies necessary configurations.
     */
    private void setupContextAndPage() {
        Browser.NewContextOptions newContext = new Browser.NewContextOptions()
                .setIgnoreHTTPSErrors(true);

        contextOptions.set(newContext);
        context.set(getDriver().newContext(newContext));
        page.set(getContext().newPage());

        getPage().setDefaultTimeout(ConfigurationManager.configuration().timeout());
        maximize();
    }

    /**
     * Reuses login state if auto-login is enabled.
     */
    public void reuseLoginState() {
        if (ConfigurationManager.configuration().autoLogin()) {
            getContextOptions().setStorageStatePath(Paths.get("storage/login.json"));
        }
        navigate(ConfigurationManager.configuration().baseUrl());
    }

    /**
     * Cleans up resources and logs test results after each test method execution.
     *
     * @param result Test result from TestNG
     */
    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        try {
            if (result.getStatus() == ITestResult.FAILURE) {
                handleTestFailure(result);
            }
        } catch (Exception e) {
            logError("Error during teardown: " + e.getMessage(), e);
        } finally {
            closeResources();
        }
    }

    /**
     * Handles test failure by adding a screenshot and logging failure details.
     */
    private void handleTestFailure(ITestResult result) {
        getTest().addScreenCaptureFromBase64String(takeSnap());
        getTest().log(Status.FAIL, "Test Failed: " + result.getThrowable());
    }

    /**
     * Closes browser resources to avoid memory leaks.
     */
    private void closeResources() {
        try {
            if (getPage() != null) getPage().close();
            if (getContext() != null) getContext().close();
            if (getPlaywright() != null) getPlaywright().close();
        } catch (Exception e) {
            logError("Error while closing resources: " + e.getMessage(), e);
        }
    }

    /**
     * Generates the final test report after the test suite execution.
     */
    @AfterSuite
    public void generateReport() {
        endResult();
    }

    /**
     * Logs errors for debugging and monitoring.
     */
    private void logError(String message, Exception e) {
        System.err.println(message);
        e.printStackTrace();
    }
}
