package mahabank.automation.data.dynamic;

import net.datafaker.Faker;

import java.util.Locale;

import static mahabank.automation.config.ConfigurationManager.configuration;

public class FakeDataFactory {

    private static final Faker faker = new Faker(new Locale(configuration().faker()));

    private FakeDataFactory() {

    }

    public static String getAddress() {
        return faker.address().streetAddress();
    }

    public static String getCity() {
        return faker.address().city();
    }
    public static String getFirstName() {
        return faker.name().firstName();
    }

    public static String getLastName() {
        return faker.name().lastName();
    }

    public static String getEmailAddress() {
        return faker.internet().emailAddress();
    }

    public static String getContactNumber() {
        return faker.phoneNumber().cellPhone();
    }

    public static String getBankAccountNumber() {
        return ""+faker.number().randomNumber(8, false);
    }

    public static String getSalutation() {
        return faker.options().option("Mr.","Ms.", "Mrs.", "Dr.", "Prof.");
    }
}